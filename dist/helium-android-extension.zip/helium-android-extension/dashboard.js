(() => {
  const $ = selector => document.querySelector(selector);
  const state = { view: "posts", query: "", postId: "", taskId: "", openTaskPosts: new Set(), data: { posts: [], comments: [], users: [] }, messageLog: {}, cloudConfig: null, cloudUser: null, cloudSyncState: { status: "idle", lastSyncedAt: 0 }, accountMode: "password", codeTimer: null };

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
  }

  function platformName(platform) {
    return platform === "xhs" ? "小红书" : platform === "douyin" ? "抖音" : platform === "kuaishou" ? "快手" : "其他";
  }

  function postNumberLabel(post) {
    const number = Number(post?.postNumber || 0);
    return number > 0 ? `帖子 #${number}` : "未编号帖子";
  }

  function taskNumberLabel(task) {
    const number = Number(task?.taskNumber || 0);
    return number > 0 ? `任务 #${number}` : "历史任务";
  }

  function taskLabelsForComment(row, post) {
    const ids = Array.isArray(row?.filterTaskIds) ? row.filterTaskIds : [];
    const tasks = Array.isArray(post?.filterTasks) ? post.filterTasks : [];
    const labels = ids.map(id => tasks.find(task => task.id === id)).filter(Boolean).map(task => taskNumberLabel(task));
    return [...new Set(labels)];
  }

  function formatDate(value) {
    if (!value) return "";
    const date = new Date(Number(value));
    return Number.isNaN(date.getTime()) ? "" : new Intl.DateTimeFormat("zh-CN", { dateStyle: "medium", timeStyle: "short" }).format(date);
  }

  function matchesQuery(values) {
    if (!state.query) return true;
    const haystack = values.filter(Boolean).join(" ").toLocaleLowerCase();
    return haystack.includes(state.query.toLocaleLowerCase());
  }

  function setNotice(message) {
    $("#notice").textContent = message || "";
  }

  function syncTimeText(value) {
    if (!value) return "尚未同步";
    const date = new Date(Number(value));
    if (Number.isNaN(date.getTime())) return "尚未同步";
    return new Intl.DateTimeFormat("zh-CN", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(date);
  }

  function setCloudSyncStatus() {
    const summary = $(".sync-summary");
    const text = $("#cloudSyncStatusText");
    const time = $("#cloudSyncLastTime");
    const loggedIn = Boolean(state.cloudConfig?.accessToken && state.cloudUser);
    const syncState = state.cloudSyncState || {};
    summary.classList.toggle("syncing", loggedIn && syncState.status === "syncing");
    summary.classList.toggle("success", loggedIn && syncState.status === "success");
    summary.classList.toggle("error", loggedIn && syncState.status === "error");
    if (!loggedIn) {
      text.textContent = "登录后自动同步";
      time.textContent = "尚未同步";
      time.dateTime = "";
      return;
    }
    text.textContent = syncState.status === "syncing"
      ? "同步中"
      : syncState.status === "success"
        ? "已自动同步"
        : syncState.status === "error"
          ? "同步失败"
          : "等待自动同步";
    time.textContent = syncTimeText(syncState.lastSyncedAt);
    time.dateTime = syncState.lastSyncedAt ? new Date(syncState.lastSyncedAt).toISOString() : "";
  }

  function setCloudAccountStatus() {
    const status = $("#cloudAccountStatus");
    const statusText = $("#cloudAccountStatusText");
    const button = $("#cloudAccountButton");
    const loggedIn = Boolean(state.cloudConfig?.accessToken && state.cloudUser);
    statusText.textContent = loggedIn ? state.cloudUser.email : "未登录";
    status.classList.toggle("connected", loggedIn);
    button.textContent = loggedIn ? "账户设置" : "登录 / 注册";
    setCloudSyncStatus();
  }

  async function loadCloudSyncState() {
    const stored = await chrome.storage.local.get({ cloudSyncState: null });
    if (stored.cloudSyncState) state.cloudSyncState = stored.cloudSyncState;
    setCloudSyncStatus();
  }

  async function loadCloudAccount() {
    const config = await CommentFilterCloudSync.getConfig();
    state.cloudConfig = config;
    state.cloudUser = null;
    if (config.accessToken) {
      try {
        const response = await CommentFilterCloudSync.getCurrentUser();
        state.cloudUser = response.user || null;
      } catch (error) {
        await CommentFilterCloudSync.logout();
        state.cloudConfig = await CommentFilterCloudSync.getConfig();
        setNotice("账户登录已过期，请重新登录。");
      }
    }
    setCloudAccountStatus();
  }

  function openCloudLoginModal() {
    const config = state.cloudConfig || {};
    $("#cloudLoginEmail").value = config.email || state.cloudUser?.email || "";
    $("#cloudLoginPassword").value = "";
    $("#accountCode").value = "";
    $("#cloudLoginNotice").textContent = state.cloudUser ? `当前账户：${state.cloudUser.email}` : "";
    $("#cloudLogoutButton").hidden = !state.cloudUser;
    $("#cloudLoginTitle").textContent = state.cloudUser ? "账户" : "账户登录";
    setAccountMode(state.cloudUser ? "password" : state.accountMode);
    $("#cloudLoginModal").hidden = false;
    $("#cloudLoginEmail").focus();
  }

  function closeCloudLoginModal() {
    $("#cloudLoginModal").hidden = true;
  }

  function setAccountMode(mode) {
    state.accountMode = mode;
    const codeMode = mode === "code" || mode === "register";
    const registerMode = mode === "register";
    $("#accountCodeWrap").hidden = !codeMode;
    $("#accountPasswordWrap").hidden = mode === "code";
    $("#accountCode").required = codeMode;
    $("#cloudLoginPassword").required = mode !== "code";
    $("#cloudLoginPassword").autocomplete = registerMode ? "new-password" : "current-password";
    $("#accountPasswordHint").textContent = registerMode ? "注册密码至少需要 12 个字符。" : "密码至少需要 12 个字符。";
    $("#submitCloudLogin").textContent = registerMode ? "注册并登录" : "登录";
    document.querySelectorAll(".account-tab").forEach(tab => {
      const active = tab.dataset.accountMode === mode;
      tab.classList.toggle("active", active);
      tab.setAttribute("aria-selected", String(active));
    });
  }

  function startCodeCooldown(seconds = 60) {
    const button = $("#sendAccountCode");
    if (state.codeTimer) clearInterval(state.codeTimer);
    let remaining = seconds;
    const update = () => {
      button.disabled = remaining > 0;
      button.textContent = remaining > 0 ? `${remaining}s 后重发` : "获取验证码";
      remaining -= 1;
      if (remaining < 0) {
        clearInterval(state.codeTimer);
        state.codeTimer = null;
      }
    };
    update();
    state.codeTimer = setInterval(update, 1000);
  }

  async function sendAccountCode() {
    const email = $("#cloudLoginEmail").value.trim();
    if (!email) {
      $("#cloudLoginNotice").textContent = "请先填写邮箱。";
      $("#cloudLoginEmail").focus();
      return;
    }
    const purpose = state.accountMode === "register" ? "register" : "login";
    const config = state.cloudConfig || await CommentFilterCloudSync.getConfig();
    const button = $("#sendAccountCode");
    button.disabled = true;
    $("#cloudLoginNotice").textContent = "正在发送验证码...";
    try {
      const result = await CommentFilterCloudSync.requestCode(email, purpose, config);
      $("#cloudLoginNotice").textContent = `验证码已发送到 ${email}，${Math.ceil((result.expiresIn || 600) / 60)} 分钟内有效。`;
      startCodeCooldown(60);
    } catch (error) {
      button.disabled = false;
      button.textContent = "获取验证码";
      $("#cloudLoginNotice").textContent = error.message || "验证码发送失败。";
    }
  }

  async function loginCloud(event) {
    event.preventDefault();
    const button = $("#submitCloudLogin");
    const email = $("#cloudLoginEmail").value.trim();
    const password = $("#cloudLoginPassword").value;
    const code = $("#accountCode").value.trim();
    if (!email || (state.accountMode !== "code" && !password) || ((state.accountMode === "code" || state.accountMode === "register") && !code)) return;
    button.disabled = true;
    $("#cloudLoginNotice").textContent = "正在登录...";
    try {
      const config = state.cloudConfig || await CommentFilterCloudSync.getConfig();
      const nextConfig = state.accountMode === "register"
        ? await CommentFilterCloudSync.register(email, code, password, config)
        : state.accountMode === "code"
          ? await CommentFilterCloudSync.loginWithCode(email, code, config)
          : await CommentFilterCloudSync.login(email, password, config);
      state.cloudConfig = nextConfig;
      const response = await CommentFilterCloudSync.getCurrentUser();
      state.cloudUser = response.user || null;
      setCloudAccountStatus();
      closeCloudLoginModal();
      try {
        await syncCloudSnapshot();
        setNotice(`已登录账户：${state.cloudUser?.email || email}，本地数据已自动同步。`);
      } catch (syncError) {
        setNotice(`已登录账户：${state.cloudUser?.email || email}，自动同步失败：${syncError.message || "请稍后重试"}`);
      }
    } catch (error) {
      $("#cloudLoginNotice").textContent = error.message || "登录失败。";
    } finally {
      button.disabled = false;
    }
  }

  async function logoutCloud() {
    await CommentFilterCloudSync.logout();
    state.cloudConfig = await CommentFilterCloudSync.getConfig();
    state.cloudUser = null;
    state.cloudSyncState = { status: "idle", lastSyncedAt: 0 };
    await chrome.storage.local.set({ cloudSyncState: state.cloudSyncState });
    setCloudAccountStatus();
    closeCloudLoginModal();
    setNotice("已退出账户，之后的数据只保存在本机。");
  }

  async function syncCloudSnapshot() {
    if (!state.cloudUser) {
      openCloudLoginModal();
      return;
    }
    state.cloudSyncState = { ...state.cloudSyncState, status: "syncing" };
    await chrome.storage.local.set({ cloudSyncState: state.cloudSyncState });
    setCloudSyncStatus();
    try {
      const snapshot = await CommentFilterDatabase.getDashboardData();
      const result = await CommentFilterCloudSync.syncSnapshot(snapshot);
      state.cloudSyncState = { status: "success", lastSyncedAt: Date.now(), counts: result.counts || {} };
      await chrome.storage.local.set({ cloudSyncState: state.cloudSyncState });
      setCloudSyncStatus();
      return result;
    } catch (error) {
      state.cloudSyncState = { ...state.cloudSyncState, status: "error" };
      await chrome.storage.local.set({ cloudSyncState: state.cloudSyncState });
      setCloudSyncStatus();
      throw error;
    }
  }

  function updateCounts() {
    $("#postCount").textContent = state.data.posts.length.toLocaleString("zh-CN");
    $("#commentCount").textContent = state.data.comments.length.toLocaleString("zh-CN");
    $("#userCount").textContent = state.data.users.length.toLocaleString("zh-CN");
    const byProfile = new Map(state.data.users.map(user => [user.profile, user]));
    state.userByProfile = byProfile;
  }

  function renderPostFilter() {
    const select = $("#postFilter");
    const selected = state.postId;
    select.innerHTML = '<option value="">全部帖子</option>' + state.data.posts.map(post =>
      `<option value="${escapeHtml(post.id)}">${escapeHtml(`${postNumberLabel(post)} · ${post.title || post.url} (${Number(post.commentCount || 0)})`)}</option>`
    ).join("");
    if (state.data.posts.some(post => post.id === selected)) select.value = selected;
    else state.postId = "";
  }

  function renderTaskFilter() {
    const select = $("#taskFilter");
    const selected = state.taskId;
    const posts = state.postId ? state.data.posts.filter(post => post.id === state.postId) : state.data.posts;
    const tasks = posts.flatMap(post => (Array.isArray(post.filterTasks) ? post.filterTasks : []).map(task => ({ task, post })));
    const taskIds = new Set(tasks.map(item => item.task.id));
    const unassignedCount = state.data.comments.filter(row => {
      if (state.postId && row.postId !== state.postId) return false;
      return !Array.isArray(row.filterTaskIds) || row.filterTaskIds.length === 0;
    }).length;
    const options = ['<option value="">全部任务</option>', ...tasks.map(({ task, post }) => {
      const number = taskNumberLabel(task);
      const title = post.title || post.url || "未命名帖子";
      return `<option value="${escapeHtml(task.id)}">${escapeHtml(`${postNumberLabel(post)} · ${number} · ${title} · 命中 ${Number(task.matchedCount || 0).toLocaleString("zh-CN")} 条`)}</option>`;
    })];
    if (unassignedCount) options.push(`<option value="__unassigned__">未关联任务（${unassignedCount.toLocaleString("zh-CN")} 条历史评论）</option>`);
    select.innerHTML = options.join("");
    select.disabled = tasks.length === 0 && !unassignedCount;
    if (taskIds.has(selected) || (selected === "__unassigned__" && unassignedCount)) select.value = selected;
    else state.taskId = "";
  }

  function renderPosts() {
    const posts = state.data.posts.filter(post => matchesQuery([post.title, post.url, post.sourceUrl, platformName(post.platform)]));
    if (!posts.length) return emptyMarkup("还没有帖子记录", "完成一次评论扫描后，帖子和评论会保存在这个浏览器的数据库里。");
    return `<div class="post-list">${posts.map(post => `
          <article class="post-entry">
        <div class="post-main">
          <div class="post-info">
            <div class="post-heading"><span class="post-number">${escapeHtml(postNumberLabel(post))}</span><span class="platform">${platformName(post.platform)}</span><h2 class="post-title">${escapeHtml(post.title || "未读取到标题")}</h2></div>
            <a class="subtle" href="${escapeHtml(post.url)}" target="_blank" rel="noreferrer">${escapeHtml(post.url)}</a>
            ${post.sourceUrl && post.sourceUrl !== post.url ? `<div class="post-source"><span>来源页</span><a href="${escapeHtml(post.sourceUrl)}" target="_blank" rel="noreferrer">${escapeHtml(post.sourceUrl)}</a></div>` : ""}
          </div>
          <div class="post-side"><div class="post-stats"><span><strong>${Number(post.commentCount || 0).toLocaleString("zh-CN")}</strong> 条评论</span><span>最近抓取 ${escapeHtml(formatDate(post.lastScannedAt) || "未知")}</span></div>
            <div class="row-actions"><button class="row-action" type="button" data-open-post="${escapeHtml(post.id)}">查看评论</button><button class="row-action" type="button" data-refresh-post="${escapeHtml(post.url)}">按当前条件更新</button><button class="row-action danger" type="button" data-delete-post="${escapeHtml(post.url)}">删除此帖数据</button></div>
          </div>
        </div>
        ${filterTasksMarkup(post)}
      </article>`).join("")}</div>`;
  }

  function filterTaskLabel(task) {
    const filters = task.filters || {};
    const parts = [];
    parts.push(`关键词：${filters.keyword || "不限"}`);
    if (filters.excludeKeyword) parts.push(`排除：${filters.excludeKeyword}`);
    parts.push(`地区：${filters.region || "不限"}`);
    parts.push(filters.matchMode === "any" ? "任一条件" : "全部条件");
    parts.push(filters.relativeDays ? `时间：${filters.relativeDays}天内` : "时间：不限");
    parts.push(`性别：${filters.genderFilter === "female" ? "女" : filters.genderFilter === "male" ? "男" : "全部"}`);
    if (filters.targetGenderCount) parts.push(`目标：${filters.targetGenderCount}人`);
    parts.push(filters.scrollLimit ? `接口页数：${filters.scrollLimit}页` : "接口页数：全部");
    parts.push(`方式：${filters.scanMode === "replace" ? "替换" : "追加"}`);
    return parts;
  }

  function filterTasksMarkup(post) {
    const tasks = Array.isArray(post.filterTasks) ? post.filterTasks : [];
    if (!tasks.length) return `<div class="post-tasks task-empty">暂无筛选任务记录</div>`;
    const latest = tasks[0];
    const preview = [latest.filters?.keyword && `关键词 ${latest.filters.keyword}`, latest.filters?.region && `地区 ${latest.filters.region}`, latest.filters?.genderFilter === "female" ? "女性" : latest.filters?.genderFilter === "male" ? "男性" : "全部性别"].filter(Boolean).join(" · ");
    return `<details class="post-tasks" data-task-post="${escapeHtml(post.id)}"${state.openTaskPosts.has(post.id) ? " open" : ""}><summary><span class="task-summary-title">${escapeHtml(postNumberLabel(post))} · 筛选任务 <span class="task-count">${tasks.length}</span></span><span class="task-preview">最近：${escapeHtml(preview)} · 命中 ${Number(latest.matchedCount || 0).toLocaleString("zh-CN")} 条</span><span class="task-chevron" aria-hidden="true"></span></summary><ol class="task-list">${tasks.map((task, index) => {
      const status = task.status === "stopped" ? "已停止" : task.status === "completed" ? "已完成" : task.status === "waiting-verification" ? "等待平台验证" : task.status;
      const taskLabel = taskNumberLabel(task);
      return `<li class="task-item"><div class="task-item-head"><div><strong>${escapeHtml(postNumberLabel(post))} · ${escapeHtml(taskLabel)}</strong><span class="task-status">${escapeHtml(status)}</span><span class="task-date">${escapeHtml(formatDate(task.completedAt || task.startedAt))}</span></div><strong class="task-result">命中 ${Number(task.matchedCount || 0).toLocaleString("zh-CN")} 条</strong></div><div class="task-tags">${filterTaskLabel(task).map(label => `<span class="task-tag">${escapeHtml(label)}</span>`).join("")}</div><div class="task-footer"><span title="${escapeHtml(task.id)}">${index === 0 ? "最近一次" : `历史任务 ${index + 1}`}</span><span class="task-actions"><button class="row-action" type="button" data-view-task="${escapeHtml(task.id)}" data-task-owner="${escapeHtml(post.id)}">查看本次评论</button><button class="row-action" type="button" data-refresh-task="${escapeHtml(task.id)}" data-task-owner="${escapeHtml(post.id)}">按此条件更新</button><button class="row-action danger" type="button" data-delete-task="${escapeHtml(task.id)}" data-task-owner="${escapeHtml(post.id)}" data-task-post-url="${escapeHtml(post.url)}">删除本次数据</button></span></div></li>`;
    }).join("")}</ol></details>`;
  }

  function genderMarkup(gender) {
    const value = gender || "未知";
    const kind = value === "女" ? "female" : value === "男" ? "male" : "";
    return `<span class="gender ${kind}">${escapeHtml(value)}</span>`;
  }

  function genderSelectMarkup(user) {
    const value = ["男", "女", "未知"].includes(user.gender) ? user.gender : "未知";
    return `<select class="gender-select" data-gender-profile="${escapeHtml(user.profile)}" aria-label="更新 ${escapeHtml(user.nickname || "用户")} 的性别"><option value="未知"${value === "未知" ? " selected" : ""}>未知</option><option value="男"${value === "男" ? " selected" : ""}>男</option><option value="女"${value === "女" ? " selected" : ""}>女</option></select>`;
  }

  function platformFromProfile(profile) {
    if (/xiaohongshu\.com/i.test(profile || "")) return "小红书";
    if (/douyin\.com/i.test(profile || "")) return "抖音";
    if (/kuaishou\.com/i.test(profile || "")) return "快手";
    return "平台";
  }

  function profileKey(profile) {
    try {
      const url = new URL(profile);
      url.search = "";
      url.hash = "";
      return url.href.replace(/\/$/, "");
    } catch (error) {
      return String(profile || "");
    }
  }

  function messageLogFor(profile) {
    return state.messageLog?.[profileKey(profile)] || null;
  }

  function messageActionMarkup(user) {
    const log = messageLogFor(user.profile);
    if (log?.status === "sent") return `<button class="row-action message-sent" type="button" disabled>已私信</button>`;
    return `<button class="row-action" type="button" data-message-profile="${escapeHtml(user.profile)}">私信</button>`;
  }

  function renderComments() {
    const comments = state.data.comments.filter(row => {
      if (state.postId && row.postId !== state.postId) return false;
      if (state.taskId === "__unassigned__" && Array.isArray(row.filterTaskIds) && row.filterTaskIds.length) return false;
      if (state.taskId && state.taskId !== "__unassigned__" && (!Array.isArray(row.filterTaskIds) || !row.filterTaskIds.includes(state.taskId))) return false;
      return matchesQuery([row.nickname, row.text, row.ipRegion, row.profileLocation, row.profileAge, row.profile, row.postUrl, row.rawTimeText]);
    });
    if (!comments.length) return emptyMarkup("没有匹配的评论", state.query || state.postId || state.taskId ? "试试修改搜索内容、帖子或任务筛选。" : "扫描到的评论会集中显示在这里。");
    const postById = new Map(state.data.posts.map(post => [post.id, post]));
    return `<div class="comment-list">${comments.map(row => {
      const user = state.userByProfile.get(row.profile) || {};
      const post = postById.get(row.postId);
      const gender = user.gender && user.gender !== "未知" ? user.gender : row.gender;
      const age = user.profileAge || row.profileAge;
      const location = user.profileLocation || row.profileLocation;
      const taskLabels = taskLabelsForComment(row, post);
      return `<article class="comment">
        <div class="comment-user"><div class="comment-name">${escapeHtml(row.nickname || "未知昵称")}${genderMarkup(gender)}</div>
          <div class="comment-meta"><span>${escapeHtml(postNumberLabel(post))}</span><span>${escapeHtml(row.rawTimeText || row.dateText || "时间未知")}</span><span>${escapeHtml(row.ipRegion || "属地未知")}</span>${age ? `<span>${escapeHtml(age)}</span>` : ""}${location ? `<span>${escapeHtml(location)}</span>` : ""}</div>
        </div>
        <div><div class="comment-text">${escapeHtml(row.text)}</div>
          <div class="comment-meta"><span>${escapeHtml(taskLabels.length ? taskLabels.join("、") : "未关联任务")}</span><span>赞 ${escapeHtml(row.likeCount || "0")}</span><span>回复 ${escapeHtml(row.replyCount || "0")}</span><span>${escapeHtml(post?.title || platformName(row.platform))}</span></div>
          <div class="comment-links">${row.profile ? `<a href="${escapeHtml(row.profile)}" target="_blank" rel="noreferrer">打开主页</a>` : ""}${row.postUrl ? `<a href="${escapeHtml(row.postUrl)}" target="_blank" rel="noreferrer" data-open-comment-post="${escapeHtml(row.postUrl)}">打开帖子</a>` : ""}</div>
        </div>
      </article>`;
    }).join("")}</div>`;
  }

  function renderUsers() {
    const commentCounts = new Map();
    for (const row of state.data.comments) {
      if (row.profile) commentCounts.set(row.profile, (commentCounts.get(row.profile) || 0) + 1);
    }
    const users = state.data.users.filter(user => matchesQuery([user.nickname, user.gender, user.profileAge, user.profileLocation, user.ipRegion, user.profile]));
    if (!users.length) return emptyMarkup("还没有可关联的用户资料", "有主页链接的评论用户会在这里按主页归并。");
    return `<div class="table-wrap"><table class="user-table"><thead><tr><th>昵称</th><th>性别</th><th>年龄线索</th><th>主页所在地</th><th>评论属地</th><th>评论数</th><th>最后出现</th><th>私信状态</th><th></th></tr></thead><tbody>${users.map(user => `
      <tr><td>${escapeHtml(user.nickname || "未知昵称")}</td><td>${genderSelectMarkup(user)}</td><td>${escapeHtml(user.profileAge || "")}</td><td>${escapeHtml(user.profileLocation || "")}</td><td>${escapeHtml(user.ipRegion || "")}</td><td>${(commentCounts.get(user.profile) || 0).toLocaleString("zh-CN")}</td><td>${escapeHtml(formatDate(user.lastSeenAt))}</td><td>${messageLogFor(user.profile)?.status === "sent" ? `<span class="message-status sent">已发送</span>` : `<span class="message-status">未记录</span>`}</td><td><div class="row-actions"><a class="row-action open-profile" href="${escapeHtml(user.profile)}" target="_blank" rel="noreferrer">主页</a>${messageActionMarkup(user)}</div></td></tr>`).join("")}</tbody></table></div>`;
  }

  function emptyMarkup(title, description) {
    return `<div class="empty"><strong>${escapeHtml(title)}</strong><span>${escapeHtml(description)}</span></div>`;
  }

  const scanSettingKeys = ["keyword", "excludeKeyword", "region", "matchMode", "relativeDays", "scrollLimit", "genderFilter", "targetGenderCount"];

  async function getLatestScanSettings() {
    const values = await chrome.storage.local.get({
      keyword: "眼线",
      excludeKeyword: "",
      region: "北京",
      matchMode: "all",
      relativeDays: 30,
      scrollLimit: 0,
      genderFilter: "all",
      targetGenderCount: 0
    });
    return Object.fromEntries(scanSettingKeys.map(key => [key, values[key]]));
  }

  function waitForScanTask(taskId) {
    return new Promise((resolve, reject) => {
      const finish = task => {
        chrome.storage.onChanged.removeListener(onChanged);
        resolve(task);
      };
      const onChanged = (changes, area) => {
        if (area !== "local") return;
        const progress = changes.scanProgress?.newValue;
        if (progress?.message) setNotice(progress.message);
        const task = changes.scanTask?.newValue;
        if (task?.id === taskId && task.status !== "running" && task.status !== "waiting-verification") finish(task);
      };

      chrome.storage.onChanged.addListener(onChanged);
      chrome.storage.local.get({ scanTask: null })
        .then(({ scanTask }) => {
          if (scanTask?.id === taskId && scanTask.status !== "running" && scanTask.status !== "waiting-verification") finish(scanTask);
          else if (!scanTask || scanTask.id !== taskId) {
            chrome.storage.onChanged.removeListener(onChanged);
            reject(new Error("未找到帖子更新任务状态，请刷新数据库后确认结果。"));
          }
        })
        .catch(error => {
          chrome.storage.onChanged.removeListener(onChanged);
          reject(error);
        });
    });
  }

  async function refreshPost(postUrl, savedFilters = null) {
    const filters = savedFilters || await getLatestScanSettings();
    const response = await chrome.runtime.sendMessage({ type: "REFRESH_POST_DATA", postUrl, filters });
    if (!response?.ok) throw new Error(response?.error || "无法开始更新帖子。");
    const taskLabel = Number(response.task?.taskNumber) > 0 ? `任务 #${Number(response.task.taskNumber)}` : "更新任务";
    setNotice(`已启动${taskLabel}，正在打开帖子页面并抓取评论...`);
    const task = await waitForScanTask(response.task?.id);
    await refresh(task?.replacementSucceeded ? "帖子评论已按当前条件更新" : task?.message || "帖子更新结束");
  }

  async function deletePost(postUrl) {
    const { scanTask, profileTask } = await chrome.storage.local.get({ scanTask: null, profileTask: null });
    if ((scanTask?.status === "running" || scanTask?.status === "waiting-verification") || profileTask?.status === "running") {
      throw new Error("当前已有任务在运行，请完成后再删除帖子数据。");
    }
    const response = await chrome.runtime.sendMessage({ type: "DELETE_POST_DATA", postUrl });
    if (!response?.ok) throw new Error(response?.error || "删除帖子数据失败。");
    state.postId = "";
    await refresh(`已删除 ${response.deletedComments || 0} 条评论及无其他引用的用户资料`);
  }

  function render() {
    $("#postFilterWrap").hidden = state.view !== "comments";
    $("#taskFilterWrap").hidden = state.view !== "comments";
    renderPostFilter();
    renderTaskFilter();
    $("#content").innerHTML = state.view === "posts" ? renderPosts() : state.view === "comments" ? renderComments() : renderUsers();
    document.querySelectorAll(".tab").forEach(tab => {
      const active = tab.dataset.view === state.view;
      tab.classList.toggle("active", active);
      tab.setAttribute("aria-selected", String(active));
    });
  }

  async function refresh(message = "") {
    try {
      const storedMessages = await chrome.storage.local.get({ directMessageLog: {} });
      state.messageLog = storedMessages.directMessageLog || {};
      state.data = await CommentFilterDatabase.getDashboardData();
      updateCounts();
      renderPostFilter();
      render();
      setNotice(message || (state.cloudUser ? "数据保存在本机，并会自动同步到你的账户。" : "数据保存在当前浏览器中"));
    } catch (error) {
      $("#content").innerHTML = emptyMarkup("数据库读取失败", error.message || "请重新加载扩展后再试。");
      setNotice("读取失败");
    }
  }

  function commentsForUser(profile) {
    const postById = new Map(state.data.posts.map(post => [post.id, post]));
    return state.data.comments
      .filter(row => row.profile === profile)
      .sort((a, b) => Number(b.collectedAt || 0) - Number(a.collectedAt || 0))
      .map(row => ({ row, post: postById.get(row.postId) }))
      .slice(0, 3);
  }

  function buildMessageDraft(user) {
    const contexts = commentsForUser(user.profile);
    const first = contexts[0];
    const nickname = user.nickname || "你好";
    const postTitle = first?.post?.title || "你评论的帖子";
    const comment = String(first?.row?.text || "").replace(/[\r\n]+/g, " ").trim().slice(0, 90);
    if (comment) return `${nickname}，你好。我看到你在《${postTitle}》下面提到“${comment}”，觉得很有意思，想和你认识一下，方便聊聊吗？`;
    return `${nickname}，你好。我看到你在${platformFromProfile(user.profile)}的评论，觉得很有意思，想和你认识一下，方便聊聊吗？`;
  }

  function openMessageModal(profile) {
    const user = state.data.users.find(item => item.profile === profile);
    if (!user) return;
    if (messageLogFor(profile)?.status === "sent") {
      setNotice("这个用户已经有本机私信记录。");
      return;
    }
    const contexts = commentsForUser(profile);
    const contextText = contexts.length
      ? `参考内容：${contexts.map(({ row, post }) => `${post?.title || "帖子"}：${row.text || ""}`).join("；")}`
      : "没有找到可用于个性化的评论内容。";
    const modal = $("#messageModal");
    modal.dataset.profile = profile;
    modal.dataset.nickname = user.nickname || "";
    modal.dataset.platform = platformFromProfile(profile);
    $("#messageModalMeta").textContent = `${user.nickname || "未知昵称"} · ${platformFromProfile(profile)}`;
    $("#messageContent").value = buildMessageDraft(user);
    $("#messageContext").textContent = contextText;
    modal.hidden = false;
    $("#messageContent").focus();
  }

  function closeMessageModal() {
    $("#messageModal").hidden = true;
    $("#messageModal").dataset.profile = "";
  }

  async function sendDirectMessage() {
    const modal = $("#messageModal");
    const profile = modal.dataset.profile || "";
    const content = $("#messageContent").value.trim();
    const button = $("#sendMessage");
    if (!profile || !content) {
      setNotice("请填写私信内容。");
      return;
    }
    if (content.length > 500) {
      setNotice("私信内容不能超过 500 个字符。");
      return;
    }
    button.disabled = true;
    button.textContent = "正在发送...";
    setNotice("正在后台打开用户主页并发送私信...");
    try {
      const contexts = commentsForUser(profile);
      const response = await chrome.runtime.sendMessage({
        type: "SEND_DIRECT_MESSAGE",
        profile,
        nickname: modal.dataset.nickname || "",
        platform: modal.dataset.platform || "",
        content,
        context: contexts.map(({ row, post }) => ({ postTitle: post?.title || "", text: row.text || "", postUrl: row.postUrl || "" }))
      });
      if (!response?.ok) throw new Error(response?.error || "私信发送失败。");
      closeMessageModal();
      await refresh("私信已发送，并已记录到本机。");
    } catch (error) {
      setNotice(error.message || "私信发送失败。请确认已登录并允许该平台私信。");
    } finally {
      button.disabled = false;
      button.textContent = "发送私信";
    }
  }

  function rowsForCopy() {
    if (state.view === "posts") {
      return state.data.posts.filter(post => matchesQuery([post.title, post.url, postNumberLabel(post), platformName(post.platform)])).map(post => [postNumberLabel(post), post.title || "", platformName(post.platform), post.commentCount || 0, post.lastScannedAt ? new Date(post.lastScannedAt).toISOString() : "", post.url]);
    }
    if (state.view === "users") {
      return state.data.users.filter(user => matchesQuery([user.nickname, user.gender, user.profileAge, user.profileLocation, user.ipRegion, user.profile])).map(user => [user.nickname, user.gender, user.profileAge, user.profileLocation, user.ipRegion, user.profile, user.commentCount || 0]);
    }
    const postById = new Map(state.data.posts.map(post => [post.id, post]));
    return state.data.comments.filter(row => {
      if (state.postId && row.postId !== state.postId) return false;
      if (state.taskId === "__unassigned__" && Array.isArray(row.filterTaskIds) && row.filterTaskIds.length) return false;
      if (state.taskId && state.taskId !== "__unassigned__" && (!Array.isArray(row.filterTaskIds) || !row.filterTaskIds.includes(state.taskId))) return false;
      return matchesQuery([row.nickname, row.text, row.ipRegion, row.profile, row.postUrl, row.rawTimeText]);
    }).map(row => {
      const post = postById.get(row.postId);
      return [postNumberLabel(post), taskLabelsForComment(row, post).join("、") || "未关联任务", row.postUrl, row.nickname, row.gender || "未知", row.dateText, row.rawTimeText, row.ipRegion, row.likeCount || 0, row.replyCount || 0, row.profile, row.text];
    });
  }

  async function copyCurrentView() {
    const header = state.view === "posts"
      ? ["帖子编号", "帖子标题", "平台", "评论数", "最近抓取", "帖子链接"]
      : state.view === "users"
        ? ["昵称", "性别", "年龄线索", "主页所在地", "评论属地", "主页链接", "评论数"]
        : ["帖子编号", "任务编号", "帖子链接", "昵称", "性别", "推算日期", "原始时间", "IP属地", "评论获赞", "回复数量", "主页链接", "评论内容"];
    const text = [header, ...rowsForCopy()].map(row => row.map(value => String(value ?? "").replace(/[\t\r\n]+/g, " ")).join("\t")).join("\n");
    try {
      await navigator.clipboard.writeText(text);
      setNotice("当前列表已复制");
    } catch (error) {
      setNotice("复制失败，请检查浏览器剪贴板权限");
    }
  }

  document.querySelectorAll(".tab").forEach(tab => tab.addEventListener("click", () => {
    state.view = tab.dataset.view;
    render();
  }));
  $("#search").addEventListener("input", event => {
    state.query = event.target.value.trim();
    render();
  });
  $("#postFilter").addEventListener("change", event => {
    state.postId = event.target.value;
    state.taskId = "";
    renderTaskFilter();
    render();
  });
  $("#taskFilter").addEventListener("change", event => {
    state.taskId = event.target.value;
    render();
  });
  $("#cloudAccountButton").addEventListener("click", openCloudLoginModal);
  document.querySelectorAll(".account-tab").forEach(tab => tab.addEventListener("click", () => {
    setAccountMode(tab.dataset.accountMode);
    $("#cloudLoginNotice").textContent = "";
  }));
  $("#sendAccountCode").addEventListener("click", () => sendAccountCode());
  $("#content").addEventListener("click", event => {
    const openCommentPost = event.target.closest("[data-open-comment-post]");
    if (openCommentPost) {
      event.preventDefault();
      openCommentPost.setAttribute("aria-busy", "true");
      setNotice("正在打开帖子并定位评论区...");
      chrome.runtime.sendMessage({ type: "OPEN_POST_COMMENTS", postUrl: openCommentPost.dataset.openCommentPost })
        .then(response => {
          if (!response?.ok) throw new Error(response?.error || "无法打开评论区");
          setNotice(response.message || "帖子已打开，并正在定位评论区。");
        })
        .catch(error => setNotice(error.message || "无法打开评论区"))
        .finally(() => openCommentPost.removeAttribute("aria-busy"));
      return;
    }

    const button = event.target.closest("[data-open-post]");
    if (button) {
      state.view = "comments";
      state.postId = button.dataset.openPost;
      state.taskId = "";
      renderPostFilter();
      render();
      return;
    }

    const viewTaskButton = event.target.closest("[data-view-task]");
    if (viewTaskButton) {
      state.view = "comments";
      state.postId = viewTaskButton.dataset.taskOwner;
      state.taskId = viewTaskButton.dataset.viewTask;
      renderPostFilter();
      renderTaskFilter();
      render();
      setNotice("已切换到这条任务获取的评论。");
      return;
    }

    const taskButton = event.target.closest("[data-refresh-task]");
    if (taskButton) {
      const post = state.data.posts.find(item => item.id === taskButton.dataset.taskOwner);
      const task = post?.filterTasks?.find(item => item.id === taskButton.dataset.refreshTask);
      if (!task) { setNotice("未找到这条筛选任务，请刷新数据库后重试。"); return; }
      if (!window.confirm("将按这条任务保存的筛选条件重新抓取此帖，并替换该帖现有评论。任务停止或失败时旧数据会保留。继续吗？")) return;
      taskButton.disabled = true;
      setNotice("正在启动帖子更新...");
      refreshPost(post.url, task.filters)
        .catch(error => setNotice(error.message || "更新帖子失败"))
        .finally(() => { taskButton.disabled = false; });
      return;
    }

    const deleteTaskButton = event.target.closest("[data-delete-task]");
    if (deleteTaskButton) {
      const taskId = deleteTaskButton.dataset.deleteTask;
      if (!window.confirm("确定删除这条任务获取的评论数据吗？如果评论也被其他任务使用，只会移除本任务关联。此操作不能撤销。")) return;
      deleteTaskButton.disabled = true;
      setNotice("正在删除本次任务数据...");
      chrome.runtime.sendMessage({ type: "DELETE_TASK_DATA", postUrl: deleteTaskButton.dataset.taskPostUrl, taskId })
        .then(response => {
          if (!response?.ok) throw new Error(response?.error || "删除任务数据失败");
          if (state.taskId === taskId) state.taskId = "";
          return refresh(`已删除本次任务 ${response.deletedComments || 0} 条评论${response.unlinkedComments ? `，解除 ${response.unlinkedComments} 条关联` : ""}`);
        })
        .catch(error => setNotice(error.message || "删除任务数据失败"))
        .finally(() => { deleteTaskButton.disabled = false; });
      return;
    }

    const refreshButton = event.target.closest("[data-refresh-post]");
    if (refreshButton) {
      if (!window.confirm("将按当前插件筛选条件重新抓取此帖，并替换该帖现有评论。任务停止或失败时旧数据会保留。继续吗？")) return;
      refreshButton.disabled = true;
      setNotice("正在启动帖子更新...");
      refreshPost(refreshButton.dataset.refreshPost)
        .catch(error => setNotice(error.message || "更新帖子失败"))
        .finally(() => { refreshButton.disabled = false; });
      return;
    }

    const deleteButton = event.target.closest("[data-delete-post]");
    if (deleteButton) {
      if (!window.confirm("确定删除这个帖子的全部评论和帖子记录吗？其他帖子仍引用的用户资料会保留。此操作不能撤销。")) return;
      deleteButton.disabled = true;
      setNotice("正在删除帖子数据...");
      deletePost(deleteButton.dataset.deletePost)
        .catch(error => setNotice(error.message || "删除帖子数据失败"))
        .finally(() => { deleteButton.disabled = false; });
      return;
    }

    const messageButton = event.target.closest("[data-message-profile]");
    if (messageButton) {
      openMessageModal(messageButton.dataset.messageProfile);
    }
  });
  $("#content").addEventListener("toggle", event => {
    const details = event.target.closest("[data-task-post]");
    if (!details) return;
    if (details.open) state.openTaskPosts.add(details.dataset.taskPost);
    else state.openTaskPosts.delete(details.dataset.taskPost);
  }, true);
  $("#content").addEventListener("change", async event => {
    const select = event.target.closest("[data-gender-profile]");
    if (!select) return;
    select.disabled = true;
    try {
      const response = await chrome.runtime.sendMessage({ type: "UPDATE_USER_GENDER", profile: select.dataset.genderProfile, gender: select.value });
      if (!response?.ok) throw new Error(response?.error || "更新用户性别失败。");
      await refresh("用户性别已更新，相关评论已同步。");
    } catch (error) {
      setNotice(error.message || "更新用户性别失败。");
      select.disabled = false;
    }
  });
  $("#refresh").addEventListener("click", () => refresh("数据库已刷新"));
  $("#copyView").addEventListener("click", copyCurrentView);

  $("#closeMessageModal").addEventListener("click", closeMessageModal);
  $("#cancelMessage").addEventListener("click", closeMessageModal);
  $("#sendMessage").addEventListener("click", () => sendDirectMessage());
  $("#messageModal").addEventListener("click", event => {
    if (event.target.id === "messageModal") closeMessageModal();
  });
  $("#cloudLoginForm").addEventListener("submit", loginCloud);
  $("#closeCloudLoginModal").addEventListener("click", closeCloudLoginModal);
  $("#cancelCloudLogin").addEventListener("click", closeCloudLoginModal);
  $("#cloudLogoutButton").addEventListener("click", () => logoutCloud().catch(error => {
    $("#cloudLoginNotice").textContent = error.message || "退出登录失败。";
  }));
  $("#cloudLoginModal").addEventListener("click", event => {
    if (event.target.id === "cloudLoginModal") closeCloudLoginModal();
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && !$("#messageModal").hidden) closeMessageModal();
    if (event.key === "Escape" && !$("#cloudLoginModal").hidden) closeCloudLoginModal();
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") return;
    if (changes.cloudSyncState) {
      state.cloudSyncState = changes.cloudSyncState.newValue || { status: "idle", lastSyncedAt: 0 };
      setCloudSyncStatus();
    }
    const scanTask = changes.scanTask?.newValue;
    const scanProgress = changes.scanProgress?.newValue;
    if ((scanTask?.status === "running" || scanTask?.status === "waiting-verification") && scanProgress?.message) {
      const taskLabel = Number(scanTask.taskNumber) > 0 ? `任务 #${Number(scanTask.taskNumber)}：` : "";
      setNotice(`${taskLabel}${scanProgress.message}`);
    }
    if (scanTask && scanTask.status !== "running" && scanTask.status !== "waiting-verification") {
      refresh(scanTask.message || "评论任务已结束").catch(error => setNotice(error.message || "刷新任务结果失败。"));
    }
  });

  Promise.all([loadCloudAccount(), loadCloudSyncState(), refresh()]).catch(error => setNotice(error.message || "数据库初始化失败。"));
})();
